# NRB PROXMOX V1 — Local QA report

Date: 2026-11-14

## Checks completed

- Python source compilation (`compileall`): PASS for application, tests, and WSGI entry point.
- ZIP archive integrity (`ZipFile.testzip`): PASS.
- ZIP contents: all 22 original project files are present under `NRB_PROXMOX_V1/`.
- Jinja template block-count sanity check: all six templates have matching basic block open/close counts.
- Static route review: public home, login/register/logout, customer dashboard/purchase/power, admin dashboard/payment review/plan creation/user toggle/Proxmox status routes are present.

## Checks deliberately not performed

- No Proxmox server connection or API request.
- No VM clone, VM configuration, resize, start/stop, or other live infrastructure action.
- No payment submission, approval, rejection, or provisioning workflow test.

## Runtime test limitation

The environment did not have Flask and its extensions installed. Installing the requirements was attempted, but package downloads were unavailable because network/DNS access failed. Therefore the automated unittest suite, live Flask startup, route rendering, and database integration could not be executed. The Python syntax and archive checks do not prove runtime correctness.

## Issues found by static review

1. Customer power controls are allowed when a VM is in `clone_submitted` state. A clone may still be running, so power actions should remain disabled until task completion and readiness are verified.
2. Admin user deactivation blocks new logins, but an already-authenticated session may remain usable because Flask-Login's `UserMixin.is_active` is not overridden to reflect the database `active` field.
3. Receipt uploads are checked by filename extension only. The app does not verify file content/MIME type or scan uploads for malware.
4. Payment approval marks a payment approved before the external provisioning operation is known to have succeeded. Provisioning failures are recorded on the VPS record, but payment status remains approved; this needs an explicit retry/refund/manual-review policy.
5. The Proxmox clone task is recorded as submitted, but there is no task polling, guest IP discovery, or transition to a verified ready state.
6. Database tables are created with `db.create_all()` at startup. Flask-Migrate is listed as a dependency, but production migrations are not implemented.

## Overall result

Static checks passed. Full runtime verification is **incomplete**. This package must not be treated as production-ready or as proof that Proxmox provisioning or payments work. Live Proxmox and payment workflows were intentionally left untouched.
