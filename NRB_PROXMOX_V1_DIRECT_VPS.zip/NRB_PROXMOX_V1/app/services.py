import os, re
from . import db
from .models import VPS, AuditLog
from .proxmox import ProxmoxClient, ProxmoxError

def audit(actor_id, action, target=None, detail=None):
    db.session.add(AuditLog(actor_id=actor_id, action=action, target=target, detail=detail))
    db.session.commit()

def provision(payment, admin_id):
    """Idempotent on payment_id. A failure is recorded; never reports false success."""
    existing = VPS.query.filter_by(payment_id=payment.id).first()
    if existing:
        return existing
    plan = payment.plan
    vm = VPS(user_id=payment.user_id, plan_id=plan.id, payment_id=payment.id,
             name=f"nrb-{payment.user_id}-{payment.id}", status="provisioning")
    db.session.add(vm)
    db.session.commit()
    try:
        client = ProxmoxClient()
        node = os.getenv("PROXMOX_DEFAULT_NODE", "")
        template = int(os.getenv("PROXMOX_TEMPLATE_VMID", "0"))
        bridge = os.getenv("PROXMOX_BRIDGE", "vmbr0")
        storage = os.getenv("PROXMOX_STORAGE", "")
        if not node or not template:
            raise ProxmoxError("Set PROXMOX_DEFAULT_NODE and PROXMOX_TEMPLATE_VMID.")
        vmid = client.next_vmid()
        vm.vmid, vm.node = vmid, node
        db.session.commit()
        upid = client.clone(node, template, vmid, vm.name, storage or None)
        # Clone is asynchronous. Keep state provisioning until an operator verifies task completion.
        vm.status = "clone_submitted"
        vm.error = f"Clone task submitted: {upid}"
        db.session.commit()
        audit(admin_id, "vps.clone_submitted", str(vmid), upid)
    except Exception as exc:
        vm.status = "failed"
        vm.error = str(exc)[:1000]
        db.session.commit()
        audit(admin_id, "vps.provision_failed", str(vm.id), vm.error)
    return vm
