from flask import Blueprint, render_template, request, redirect, url_for, flash
from flask_login import login_user, logout_user, current_user
from . import db, limiter
from .models import User

bp = Blueprint("auth", __name__)

@bp.route("/register", methods=["GET", "POST"])
@limiter.limit("5 per hour")
def register():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        if len(email) > 255 or "@" not in email or len(password) < 12:
            flash("Enter a valid email and a password of at least 12 characters.")
        elif User.query.filter_by(email=email).first():
            flash("An account with that email already exists.")
        else:
            user = User(email=email, password_hash=User.hash_password(password))
            db.session.add(user); db.session.commit()
            login_user(user)
            return redirect(url_for("customer.dashboard"))
    return render_template("auth.html", mode="register")

@bp.route("/login", methods=["GET", "POST"])
@limiter.limit("8 per minute")
def login():
    if request.method == "POST":
        user = User.query.filter_by(email=request.form.get("email", "").strip().lower()).first()
        if user and user.active and user.check_password(request.form.get("password", "")):
            login_user(user, remember=False)
            return redirect(url_for("admin.dashboard" if user.role == "admin" else "customer.dashboard"))
        flash("Invalid credentials or inactive account.")
    return render_template("auth.html", mode="login")

@bp.post("/logout")
def logout():
    logout_user()
    return redirect(url_for("main.index"))
